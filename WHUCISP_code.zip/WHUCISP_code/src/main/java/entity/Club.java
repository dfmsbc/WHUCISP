package entity;

public class Club {

    private int Id;
    private String ClubName;

    public int getId(){return Id;}
    public void setId(int id){ Id = id; }

    public String getClubName(){return ClubName;}
    public void setClubName(String clubName){ClubName = clubName;}

}
