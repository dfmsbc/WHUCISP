package apply.Dao;

import entity.Apply;

public interface ApplyDao {
    Boolean insert (Apply apply);
}
