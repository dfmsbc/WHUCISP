package apply.Service;

public interface ApplyService {
    String apply(String name, String schoolID, String club, String telephone, String selfIntro);
}
